package co.edu.cotecnova.facturacionelectronica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturacionElectronicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturacionElectronicaApplication.class, args);
	}

}
